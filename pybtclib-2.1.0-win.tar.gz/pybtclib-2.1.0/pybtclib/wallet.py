import hashlib
import sys
import ecdsa
import base58
import bech32
from pybtclib.utils import usage


class Wallet:
    def __init__(self):
        self.private_key_hex = None
        self.compressed_wif = None
        self.uncompressed_wif = None

    def hex_to_compressed_wif(self):
        if not self.private_key_hex:
            raise ValueError("Please Provide Hex Private Key")
        private_key_bytes = bytes.fromhex(self.private_key_hex)
        prefix = b'\x80'
        suffix = b'\x01'
        extended_key = prefix + private_key_bytes + suffix
        checksum = hashlib.sha256(hashlib.sha256(extended_key).digest()).digest()[:4]
        final_key = extended_key + checksum
        compressed_wif = self.encode_base58(final_key)
        return compressed_wif

    def hex_to_uncompressed_wif(self):
        if not self.private_key_hex:
            raise ValueError("Please Provide Hex Private Key")
        private_key_bytes = bytes.fromhex(self.private_key_hex)
        prefix = b'\x80'
        extended_key = prefix + private_key_bytes
        checksum = hashlib.sha256(hashlib.sha256(extended_key).digest()).digest()[:4]
        final_key = extended_key + checksum
        uncompressed_wif = self.encode_base58(final_key)
        return uncompressed_wif

    def hex_to_compressed_address(self):
        vk = self.pre_process_data()
        x_coord = vk.pubkey.point.x()
        y_coord = vk.pubkey.point.y()
        if y_coord % 2 == 0:
            compressed_prefix = b'\x02'
        else:
            compressed_prefix = b'\x03'
        compressed_public_key = compressed_prefix + x_coord.to_bytes(32, 'big')
        h160 = self.hash160(compressed_public_key)
        network_byte = b'\x00'
        payload = network_byte + h160
        checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
        address = payload + checksum
        compressed_address = base58.b58encode(address)

        return compressed_address.decode('utf-8')

    def hex_to_uncompressed_address(self):
        vk = self.pre_process_data()
        public_key_bytes = b'\x04' + vk.to_string()
        h160 = self.hash160(public_key_bytes)
        network_byte = b'\x00'
        payload = network_byte + h160
        checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
        address = payload + checksum
        p2pkh_address = base58.b58encode(address)

        return p2pkh_address.decode('utf-8')

    def hex_to_segwit_address(self):
        vk = self.pre_process_data()
        x_coord = vk.pubkey.point.x()
        y_coord = vk.pubkey.point.y()
        if y_coord % 2 == 0:
            compressed_prefix = b'\x02'
        else:
            compressed_prefix = b'\x03'
        compressed_public_key = compressed_prefix + x_coord.to_bytes(32, 'big')
        h160 = self.hash160(compressed_public_key)
        witness_program = h160
        hrp = 'bc'
        witness_version = 0
        bech32_address = bech32.encode(hrp, witness_version, witness_program)
        return bech32_address

    def uncompressed_wif_to_hex(self):
        if not self.uncompressed_wif:
            raise ValueError("Please Provide Uncompressed WIF")
        decoded = base58.b58decode(self.uncompressed_wif)
        version_byte = decoded[0]
        private_key_bytes = decoded[1:-4]
        checksum = decoded[-4:]
        extended_key = version_byte.to_bytes(1, 'big') + private_key_bytes
        calculated_checksum = hashlib.sha256(hashlib.sha256(extended_key).digest()).digest()[:4]
        if calculated_checksum != checksum:
            raise ValueError("Invalid WIF checksum")
        hex_private_key = private_key_bytes.hex()
        return hex_private_key

    def compressed_wif_to_hex(self):
        if not self.compressed_wif:
            raise ValueError("Please Provide Compressed WIF")
        decoded = base58.b58decode(self.compressed_wif)
        version_byte = decoded[0]
        private_key_bytes = decoded[1:-4]
        checksum = decoded[-4:]
        extended_key = version_byte.to_bytes(1, 'big') + private_key_bytes
        calculated_checksum = hashlib.sha256(hashlib.sha256(extended_key).digest()).digest()[:4]
        if calculated_checksum != checksum:
            raise ValueError("Invalid WIF checksum")
        hex_private_key = private_key_bytes.hex()
        return hex_private_key[:-2]

    def hash160(self, s):
        sha256_hash = hashlib.sha256(s).digest()
        ripemd160_hash = hashlib.new('ripemd160')
        ripemd160_hash.update(sha256_hash)
        return ripemd160_hash.digest()

    @usage
    def pre_process_data(self):
        if all([self.private_key_hex, self.compressed_wif, self.uncompressed_wif]):
            raise ValueError("Please Provide Some Private Key")

        if self.compressed_wif:
            self.private_key_hex = self.compressed_wif_to_hex()

        if self.uncompressed_wif:
            self.private_key_hex = self.uncompressed_wif_to_hex()
        private_key_bytes = bytes.fromhex(self.private_key_hex)
        private_key_int = int.from_bytes(private_key_bytes, 'big')
        sk = ecdsa.SigningKey.from_secret_exponent(private_key_int, curve=ecdsa.SECP256k1)
        vk = sk.get_verifying_key()
        return vk

    def encode_base58(self, b):
        zeros = 0
        for byte in b:
            if byte == 0x00:
                zeros += 1
            else:
                break
        b58 = '1' * zeros
        num = int.from_bytes(b, 'big')
        alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
        while num > 0:
            num, remainder = divmod(num, 58)
            b58 = alphabet[remainder] + b58

        return b58

    def json_detail(self):
        c_address = self.hex_to_compressed_address()
        u_address = self.hex_to_uncompressed_address()
        segwit_address = self.hex_to_segwit_address()
        c_wif = self.hex_to_compressed_wif()
        u_wif = self.hex_to_uncompressed_wif()

        return {
            "P2PKH(c)": c_address,
            "P2PKH(u)": u_address,
            "BECH32(c)": segwit_address,
            "WIF(c)": c_wif,
            "WIF(u)": u_wif,
            "HEX": self.private_key_hex,
        }

    def str_detail(self):
        c_address = self.hex_to_compressed_address()
        u_address = self.hex_to_uncompressed_address()
        segwit_address = self.hex_to_segwit_address()
        c_wif = self.hex_to_compressed_wif()
        u_wif = self.hex_to_uncompressed_wif()
        print(f"P2PKH(c): {c_address}")
        print(f"P2PKH(u): {u_address}")
        print(f"BECH32(c): {segwit_address}")
        print(f"WIF(c): {c_wif}")
        print(f"WIF(u): {u_wif}")
        print(f"HEX: {self.private_key_hex}")


wallet = Wallet()
